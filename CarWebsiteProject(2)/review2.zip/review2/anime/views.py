from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm 
from .models import Car_Info
from .models import Review
from .forms import ReviewForm
from .forms import FormName
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
def index(request):
    reviews = Review.objects.order_by('-date_added')

    context = {'reviews' : reviews}

    return render(request, 'anime/index.html', context)


def sign(request):
    if request.method == 'POST':
        print("here1")
        form = ReviewForm(request.POST)
        user = request.user
        if form.is_valid():
            new_review = Review(name=request.POST['name'] + "- " + user.username ,review = request.POST['review'])
            new_review.save()
            print("review form saved")
            return redirect('index')

    else:
        form = ReviewForm()

    context = {'form' : form}
    return render(request, 'anime/sign.html',context)
    return render(request, 'anime/CarComp.html',context)            

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username = username,password = password)
            login(request,user)
            return redirect('index')
    else:
        form = UserCreationForm()

    context = {'form': form}
    return render(request, 'registration/register.html',context)

def car(request):
    form2 = FormName()
    print(Car_Info)

    return render(request, 'anime/CarComp.html', {"form2":form2})


def contact(request):
    if request.method == "POST":
        a = request.POST('Clist')
        print(a)
    
    context_dict = {'Car_Info': Car_Info.objects.all()}
    
    return render(request,'anime/CarComp.html',)