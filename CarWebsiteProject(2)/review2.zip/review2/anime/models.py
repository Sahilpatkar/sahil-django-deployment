from django.db import models
from django.utils import timezone
# Create your models here.

class Review(models.Model):
	name = models.CharField(max_length=20)
	#username = models.CharField(max_length=20)
	review = models.TextField()
	date_added = models.DateTimeField(default=timezone.now)

	def __str__(self):
		return 'Name:{}'.format(self.name)

class Car_Info(models.Model):
	CarName = models.CharField(max_length=50)
	length = models.CharField(max_length=10)
	widht = models.CharField(max_length=10)
	height = models.CharField(max_length=10)
	wheel_base = models.CharField(max_length=10)
	ground_clearance = models.CharField(max_length=10)
	Boot_capacity = models.CharField(max_length=10)
	Fuel_type = models.CharField(max_length=10)
	Engine_displacement = models.CharField(max_length=10)
	Engine_type = models.CharField(max_length=10)
	Max_power = models.CharField(max_length=20)

	def __str__(self):
		return self.CarName